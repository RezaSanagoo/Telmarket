import type { ThemeConfig } from "antd";

const theme: ThemeConfig = {
  token: {
    fontFamily: 'inherit'
  },
};

export default theme;
